TOKEN_TALKS = ''  # | Переговораня
TOKEN_ANONYM = ''  # | Аноноим
TOKEN_POLICE = ''  # | Майор
TOKEN_FORTUNETELLER = ''  # | Гадалка
TOKEN_JOURNALIST = ''  # | Новостной блог
TOKEN_CRIMINALIST = ''  # | Криминалист
TOKEN_ADMIN = ''  # | Админка

URL_B = '/api'

ID_PERSON = ''
MY_ID = ''